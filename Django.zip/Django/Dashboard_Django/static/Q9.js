const margin9 = { top: 30, right: 50, bottom: 50, left: 120 },
      width9 = 450,
      height9 = 200;

d3.json("/q9-data/").then(df_result => {
  if (!df_result || df_result.length === 0) {
    d3.select("#Q9").append("div").style("color","red")
      .text("Không có dữ liệu từ API");
    return;
  }

  // Gom nhóm theo "Nhóm hàng"
  const groupedData9 = d3.groups(df_result, d => d["Nhóm hàng"]);

  // Thứ tự hiển thị
  const orderedGroups9 = [
    "[BOT] Bột",
    "[SET] Set trà",
    "[THO] Trà hoa",
    "[TMX] Trà mix",
    "[TTC] Trà củ, quả sấy"
  ];

  const sortedGroupedData9 = orderedGroups9
    .map(g => groupedData9.find(d => d[0] === g))
    .filter(d => d);

  // SVG chính, căn giữa
  const q9 = d3.select("#Q9")
    .append("svg")
    .attr("width", (width9 + margin9.left + margin9.right) * 3)
    .attr("height", (height9 + margin9.top + margin9.bottom) * 2)
    .style("display", "block")
    .style("margin", "0 auto");

  const colorScale9 = d3.scaleOrdinal(d3.schemeCategory10);
  const tooltip9 = d3.select("body").append("div")
    .attr("class", "tooltip")
    .style("opacity", 0)
    .style("position", "absolute")
    .style("background", "#fff")
    .style("border", "1px solid #ccc")
    .style("padding", "10px")
    .style("pointer-events", "none");

  const groupSpacing9 = (width9 + margin9.right);

  sortedGroupedData9.forEach(([group, data], index) => {
    const row = Math.floor(index / 3);
    const col = index % 3;

    const xOffset = col * groupSpacing9 + margin9.left;
    const yOffset = row * (height9 + margin9.bottom) + margin9.top;

    const groupChart = q9.append("g")
      .attr("transform", `translate(${xOffset},${yOffset})`);

    // Scale X khác nhau theo nhóm
    let xScale, xAxis;
    if (group.includes("Bột")) {
      xScale = d3.scaleLinear().domain([0, 1.0]).range([0, width9 - margin9.left - margin9.right]);
      xAxis = d3.axisBottom(xScale).tickValues([0, 0.5, 1.0]).tickFormat(d3.format(".0%"));
    } else if (group.includes("Set trà")) {
      xScale = d3.scaleLinear().domain([0, 0.2]).range([0, width9 - margin9.left - margin9.right]);
      xAxis = d3.axisBottom(xScale).tickValues([0,0.10,0.20]).tickFormat(d3.format(".0%"));
    } else if (group.includes("Trà hoa")) {
      xScale = d3.scaleLinear().domain([0, 0.2]).range([0, width9 - margin9.left - margin9.right]);
      xAxis = d3.axisBottom(xScale).tickValues([0,0.2]).tickFormat(d3.format(".0%"));
    } else if (group.includes("Trà củ, quả sấy")) {
      xScale = d3.scaleLinear().domain([0, 0.6]).range([0, width9 - margin9.left - margin9.right]);
      xAxis = d3.axisBottom(xScale).tickValues([0,0.2,0.4,0.6]).tickFormat(d3.format(".0%"));
    } else if (group.includes("Trà mix")) {
      xScale = d3.scaleLinear().domain([0, 0.4]).range([0, width9 - margin9.left - margin9.right]);
      xAxis = d3.axisBottom(xScale).tickValues([0,0.2,0.4]).tickFormat(d3.format(".0%"));
    } else {
      xScale = d3.scaleLinear().domain([0, 1]).range([0, width9 - margin9.left - margin9.right]);
      xAxis = d3.axisBottom(xScale).tickFormat(d3.format(".0%"));
    }

    // Scale Y
    const y = d3.scaleBand()
      .domain(data.map(d => d["Mặt hàng"]))
      .range([0, height9])
      .padding(0.3);

    // Bars
    groupChart.append("g")
      .selectAll("rect")
      .data(data)
      .enter()
      .append("rect")
      .attr("class", "bar")
      .attr("x", 0)
      .attr("y", d => y(d["Mặt hàng"]))
      .attr("width", d => xScale(d["Xác suất bán"]))
      .attr("height", y.bandwidth())
      .attr("fill", d => colorScale9(d["Mặt hàng"]))
      .on("mouseover", function (event, d) {
        tooltip9.transition().duration(200).style("opacity", 0.9);
        tooltip9.html(`
          <table style="border-collapse:collapse;">
            <tr><td>Mặt hàng</td><td><strong>${d["Mặt hàng"]}</strong></td></tr>
            <tr><td>Xác suất</td><td><strong>${(d["Xác suất bán"]*100).toFixed(1)}%</strong></td></tr>
            <tr><td>Tổng đơn nhóm</td><td><strong>${d["Tổng đơn nhóm"]}</strong></td></tr>
          </table>
        `)
        .style("left", (event.pageX + 10) + "px")
        .style("top", (event.pageY - 28) + "px");
      })
      .on("mouseout", () => tooltip9.transition().duration(500).style("opacity", 0));

    // Label %
    groupChart.append("g")
      .selectAll("text")
      .data(data)
      .enter()
      .append("text")
      .attr("x", d => xScale(d["Xác suất bán"]) + 5)
      .attr("y", d => y(d["Mặt hàng"]) + y.bandwidth() / 2)
      .attr("dy", ".35em")
      .text(d => `${(d["Xác suất bán"] * 100).toFixed(0)}%`)
      .style("font-size", "10px")
      .style("fill", "black");

    // Trục X
    groupChart.append("g")
      .attr("transform", `translate(0,${height9})`)
      .call(xAxis)
      .style("font-size", "10px");

    // Trục Y
    groupChart.append("g")
      .call(d3.axisLeft(y))
      .call(g => g.select(".domain").remove())
      .selectAll("text")
      .style("font-size", "10px");

    // Title nhóm
    groupChart.append("text")
      .attr("x", width9 / 2 - margin9.left)
      .attr("y", -5)
      .attr("text-anchor", "middle")
      .attr("font-size", "13px")
      .attr("font-weight", "bold")
      .text(group);
  });
}).catch(err => {
  console.error("Q9.js error:", err);
  d3.select("#Q9").append("div").style("color","red")
    .text("Lỗi load /q9-data/");
});
