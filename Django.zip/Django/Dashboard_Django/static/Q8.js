(function(){
  d3.select("#Q8").selectAll("*").remove();
  d3.selectAll(".q8-tooltip").remove();

  d3.json("/q8-data/").then(rows => {
    if (!rows || rows.length === 0) {
      d3.select("#Q8").append("div").style("color","red")
        .text("Không có dữ liệu từ API");
      return;
    }

    // Gom lại theo nhóm hàng
    const groups = Array.from(new Set(rows.map(d => d["Mã nhóm hàng"] + "|" + d["Tên nhóm hàng"])))
      .map(key => {
        const [code, name] = key.split("|");
        return { groupCode: code, groupName: name };
      });

    const dataByGroup = groups.map(g => {
      const values = [];
      for (let m = 1; m <= 12; m++) {
        const rec = rows.find(d => d["Tháng"] === m && d["Mã nhóm hàng"] === g.groupCode);
        values.push({
          month: m,
          so_don: rec ? rec["Số đơn"] : 0,
          xac_suat: rec ? rec["Xác suất"] : 0
        });
      }
      return { groupCode: g.groupCode, groupName: g.groupName, values };
    });

    // --- Vẽ biểu đồ ---
    const width = 1000, height = 600;
    const margin = { top: 60, right: 160, bottom: 80, left: 100 };

    const svg = d3.select("#Q8").append("svg")
      .attr("width", width)
      .attr("height", height)
      .style("font-family", "Arial, sans-serif")
      .style("border", "none");   // bỏ viền

    const x = d3.scaleLinear()
      .domain([1, 12])
      .range([margin.left, width - margin.right]);

    const y = d3.scaleLinear()
      .domain([0.2, 0.7])   // fix 20% đến 70%
      .range([height - margin.bottom, margin.top]);

    // Trục X
    svg.append("g")
      .attr("transform", `translate(0,${height - margin.bottom})`)
      .call(d3.axisBottom(x).ticks(12).tickFormat(d => `Tháng ${String(d).padStart(2,"0")}`))
      .call(g => g.select(".domain").remove())
      .call(g => g.selectAll(".tick line").remove())
      .style("font-size", "11px");

    // Trục Y
    svg.append("g")
      .attr("transform", `translate(${margin.left},0)`)
      .call(d3.axisLeft(y)
        .tickValues([0.2,0.3,0.4,0.5,0.6,0.7])
        .tickFormat(d => (d*100).toFixed(0) + "%"))
      .call(g => g.select(".domain").remove())
      .style("font-size", "11px");

    // Grid ngang
    const innerW = width - margin.left - margin.right;
    svg.append("g")
      .attr("transform", `translate(${margin.left},0)`)
      .call(d3.axisLeft(y)
        .tickValues([0.2,0.3,0.4,0.5,0.6,0.7])
        .tickSize(-innerW)
        .tickFormat(""))
      .lower()
      .selectAll("line")
      .style("stroke", "#e0e0e0");

    // Tooltip
    const tooltip = d3.select("body").append("div").attr("class","q8-tooltip")
      .style("position","absolute").style("pointer-events","none")
      .style("background","#fff").style("border","1px solid #ccc")
      .style("padding","6px 10px").style("border-radius","4px")
      .style("font-size","12px").style("opacity",0);

    const color = d3.scaleOrdinal(d3.schemeTableau10);
    const lineGen = d3.line().x(d => x(d.month)).y(d => y(d.xac_suat));

    // Đường line
    svg.selectAll(".line-group")
      .data(dataByGroup)
      .enter().append("path")
      .attr("class", "line-group")
      .attr("d", d => lineGen(d.values))
      .style("fill","none")
      .style("stroke",(d,i) => color(i))
      .style("stroke-width",2);

    // Dots
    svg.selectAll(".dot")
      .data(dataByGroup.flatMap(g => g.values.map(v => ({...v, groupCode:g.groupCode, groupName:g.groupName}))))
      .enter().append("circle")
      .attr("cx", d => x(d.month))
      .attr("cy", d => y(d.xac_suat))
      .attr("r", 3)
      .style("fill", (d,i) => {
        const idx = groups.findIndex(g => g.groupCode === d.groupCode && g.groupName === d.groupName);
        return color(idx);
      })
      .on("mouseover", function(event, d){
        tooltip.transition().duration(100).style("opacity",1);
        tooltip.html(`
          <strong>Tháng ${String(d.month).padStart(2,"0")}</strong><br/>
          [${d.groupCode}] ${d.groupName}: ${(d.xac_suat*100).toFixed(1)}%
        `)
        .style("left",(event.pageX+10)+"px")
        .style("top",(event.pageY-28)+"px");
      })
      .on("mouseout", () => tooltip.transition().duration(300).style("opacity",0));

    // Legend
    const legend = svg.append("g")
      .attr("transform", `translate(${width - margin.right + 20}, ${margin.top})`);

    legend.append("text")
      .attr("x", 0)
      .attr("y", 0)
      .text("Nhóm hàng")
      .style("font-size","12px")
      .style("font-weight","bold");

    legend.selectAll(".legend-item")
      .data(dataByGroup)
      .enter().append("g")
      .attr("class","legend-item")
      .attr("transform",(d,i)=>`translate(0, ${(i+1)*18 + 15})`)
      .each(function(d,i){
        d3.select(this).append("circle")
          .attr("cx",6).attr("cy",0).attr("r",6)
          .attr("fill",color(i));
        d3.select(this).append("text")
          .attr("x",18).attr("y",0).attr("dy","0.35em")
          .style("font-size","10px")
          .text(`[${d.groupCode}] ${d.groupName}`);
      });
  }).catch(err => {
    console.error("Q8.js load error:", err);
    d3.select("#Q8").append("div").style("color","red").text("Lỗi load /q8-data/");
  });
})();
