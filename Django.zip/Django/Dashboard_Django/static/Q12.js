d3.json("/q12-data/").then(binnedData => {
    console.log("Q12 data:", binnedData);  // kiểm tra dữ liệu vào

    if (!binnedData || binnedData.length === 0) {
        d3.select("#Q12").append("div").style("color","red")
          .text("Không có dữ liệu Q12");
        return;
    }

    const margin = { top: 40, right: 40, bottom: 60, left: 80 };
    const width = 1000;
    const height = 500;

    const svg = d3.select("#Q12")
        .append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom);

    const chart = svg.append("g")
        .attr("transform", `translate(${margin.left},${margin.top})`);

    const x = d3.scaleBand()
        .domain(binnedData.map(d => d["Khoảng chi tiêu"]))
        .range([0, width])
        .padding(0.2);

    const y = d3.scaleLinear()
        .domain([0, d3.max(binnedData, d => d["Số lượng KH"])]).nice()
        .range([height, 0]);

    // === Tooltip div ===
    const tooltip = d3.select("body")
        .append("div")
        .style("position", "absolute")
        .style("background", "#fff")
        .style("border", "1px solid #ccc")
        .style("padding", "6px 10px")
        .style("border-radius", "4px")
        .style("box-shadow", "0px 2px 6px rgba(0,0,0,0.2)")
        .style("pointer-events", "none")
        .style("opacity", 0);

    // Bars
    chart.selectAll(".bar")
        .data(binnedData)
        .enter()
        .append("rect")
        .attr("class", "bar")
        .attr("x", d => x(d["Khoảng chi tiêu"]))
        .attr("y", d => y(d["Số lượng KH"]))
        .attr("width", x.bandwidth())
        .attr("height", d => height - y(d["Số lượng KH"]))
        .attr("fill", "#00bcd4")
        .on("mouseover", (event, d) => {
            tooltip.style("opacity", 1)
                .html(`
                    <strong>Khoảng chi tiêu:</strong> ${d["Khoảng chi tiêu"]}<br/>
                    <strong>Số lượng KH:</strong> ${d["Số lượng KH"].toLocaleString("vi-VN")}
                `);
        })
        .on("mousemove", (event) => {
            tooltip.style("left", (event.pageX + 10) + "px")
                   .style("top", (event.pageY - 28) + "px");
        })
        .on("mouseout", () => {
            tooltip.style("opacity", 0);
        });

    // Trục Y
    chart.append("g")
        .call(d3.axisLeft(y))
        .select(".domain").remove();  // ẩn trục chính
});
