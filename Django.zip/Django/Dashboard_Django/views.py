from django.shortcuts import render
from django.http import JsonResponse
from django.db.models import Sum
from .models import SaleRecord
from django.db.models.functions import ExtractMonth
from django.db.models.functions import TruncDate, ExtractWeekDay, ExtractDay
from django.db.models.functions import ExtractHour
from django.db.models import Count

from django.db.models import Avg



def chart_view(request):
    # chỉ render template, không cần truyền data
    return render(request, "index.html")

def q1_data(request):
    qs = (
        SaleRecord.objects
        .values("Ma_mat_hang", "Ten_mat_hang", "Ma_nhom_hang", "Ten_nhom_hang")
        .annotate(total=Sum("Thanh_tien"), sl=Sum("SL"))
    )
    data = [
        {
            "Mã mặt hàng": q["Ma_mat_hang"],
            "Tên mặt hàng": q["Ten_mat_hang"],
            "Mã nhóm hàng": q["Ma_nhom_hang"],
            "Tên nhóm hàng": q["Ten_nhom_hang"],
            "Thành tiền": q["total"],
            "SL": q["sl"],
        }
        for q in qs
    ]
    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})

def q2_data(request):
    qs = (
        SaleRecord.objects
        .values("Ma_nhom_hang", "Ten_nhom_hang")
        .annotate(total=Sum("Thanh_tien"), sl=Sum("SL"))
    )
    data = [
        {
            "Mã nhóm hàng": q["Ma_nhom_hang"],
            "Tên nhóm hàng": q["Ten_nhom_hang"],
            "Thành tiền": q["total"],
            "SL": q["sl"],
        }
        for q in qs
    ]
    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})

def q3_data(request):
    qs = (
        SaleRecord.objects
        .annotate(thang=ExtractMonth("Thoi_gian_tao_don")) # type: ignore
        .values("thang")
        .annotate(total=Sum("Thanh_tien"), sl=Sum("SL"))
        .order_by("thang")
    )
    data = [
        {
            "Tháng": f"Tháng {str(q['thang']).zfill(2)}",
            "Tháng_num": q["thang"],
            "Thành tiền": q["total"],
            "SL": q["sl"],
        }
        for q in qs
    ]
    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})

def q4_data(request):
    # B1: tổng doanh số theo NGÀY (đã cắt giờ)
    daily = (
        SaleRecord.objects
        .annotate(date=TruncDate("Thoi_gian_tao_don"),
                  wd=ExtractWeekDay("Thoi_gian_tao_don"))  # 1=CN, 2=Thứ Hai, ... 7=Thứ Bảy
        .values("date", "wd")
        .annotate(total=Sum("Thanh_tien"))
        .order_by("date")
    )

    # B2: tính TRUNG BÌNH theo thứ trong tuần (trung bình của TỔNG/TỪNG-NGÀY)
    totals = {i: 0 for i in range(1, 8)}
    counts = {i: 0 for i in range(1, 8)}
    for row in daily:
        wd = row["wd"]                    # 1..7
        totals[wd] += row["total"] or 0
        counts[wd] += 1

    weekday_map = {2:"Thứ Hai",3:"Thứ Ba",4:"Thứ Tư",5:"Thứ Năm",6:"Thứ Sáu",7:"Thứ Bảy",1:"Chủ Nhật"}
    order = [2,3,4,5,6,7,1]

    data = [
        {"Ngày trong tuần": weekday_map[i],
         "Thành tiền": (totals[i] / counts[i]) if counts[i] else 0}
        for i in order
    ]
    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})


def q5_data(request):
    # B1: tổng theo ngày
    daily = (
        SaleRecord.objects
        .annotate(date=TruncDate("Thoi_gian_tao_don"),
                  day=ExtractDay("Thoi_gian_tao_don"))
        .values("date", "day")
        .annotate(total=Sum("Thanh_tien"))
        .order_by("date")
    )

    # B2: gom theo "ngày trong tháng"
    totals, counts = {}, {}
    for row in daily:
        d = row["day"]
        totals[d] = totals.get(d, 0) + row["total"]
        counts[d] = counts.get(d, 0) + 1

    data = [
        {
            "Ngày trong tháng": f"Ngày {str(i).zfill(2)}",
            "Doanh số TB": (totals[i] / counts[i]) if counts.get(i) else 0
        }
        for i in sorted(totals.keys())
    ]

    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})

def q6_data(request):
    """
    Trả JSON: Doanh số trung bình theo khung giờ.
    - denom=active  (mặc định): chia cho SỐ NGÀY CÓ ĐƠN ở giờ đó
    - denom=calendar: chia cho TỔNG SỐ NGÀY trong tập dữ liệu
    """
    denom = request.GET.get("denom", "active")

    # B1: tổng doanh số theo (ngày, giờ)
    daily_hour = (
        SaleRecord.objects
        .annotate(date=TruncDate("Thoi_gian_tao_don"),
                  hour=ExtractHour("Thoi_gian_tao_don"))
        .values("date", "hour")
        .annotate(total=Sum("Thanh_tien"))
        .order_by("date", "hour")
    )

    # Tổng số ngày trong toàn tập (để dùng khi denom=calendar)
    distinct_days = set()
    for row in daily_hour:
        distinct_days.add(row["date"])
    total_calendar_days = len(distinct_days) if distinct_days else 0

    # B2: gộp lại theo giờ, tính tổng và đếm số ngày có phát sinh cho giờ đó
    totals = {h: 0 for h in range(24)}
    counts = {h: 0 for h in range(24)}  # số ngày CÓ đơn ở giờ đó

    # daily_hour đã unique theo (date, hour), nên mỗi row là tổng của 1 ngày–1 giờ
    for row in daily_hour:
        h = row["hour"] if row["hour"] is not None else 0
        totals[h] += row["total"] or 0
        counts[h] += 1

    # B3: tính trung bình
    data = []
    for h in range(8,23):
        if denom == "calendar":
            divisor = total_calendar_days or 1
        else:  # "active"
            divisor = counts[h] or 1
        avg = totals[h] / divisor
        data.append({
            "Khung giờ": f"{h:02d}:00-{h:02d}:59",
            "Doanh số TB": avg
        })

    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})

def q7_data(request):
    # Đếm số đơn hàng duy nhất trong toàn bộ bảng
    total_orders = SaleRecord.objects.values("Ma_don_hang").distinct().count()

    # Đếm số đơn hàng duy nhất cho từng nhóm hàng
    qs = (
        SaleRecord.objects
        .values("Ma_nhom_hang", "Ten_nhom_hang")
        .annotate(so_don=Count("Ma_don_hang", distinct=True))
    )

    data = []
    for row in qs:
        nhom = f"[{row['Ma_nhom_hang']}] {row['Ten_nhom_hang']}"
        xac_suat = row["so_don"] / total_orders if total_orders else 0
        data.append({
            "Mã nhóm hàng": row["Ma_nhom_hang"],
            "Tên nhóm hàng": row["Ten_nhom_hang"],
            "Nhóm hàng": nhom,
            "Số đơn": row["so_don"],
            "Xác suất": xac_suat,
        })

    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})

def q8_data(request):
    # Tổng số đơn hàng mỗi tháng
    total_orders_by_month = (
        SaleRecord.objects
        .annotate(month=ExtractMonth("Thoi_gian_tao_don"))
        .values("month")
        .annotate(total=Count("Ma_don_hang", distinct=True))
    )
    total_map = {row["month"]: row["total"] for row in total_orders_by_month}

    # Số đơn hàng theo nhóm hàng + tháng
    qs = (
        SaleRecord.objects
        .annotate(month=ExtractMonth("Thoi_gian_tao_don"))
        .values("month", "Ma_nhom_hang", "Ten_nhom_hang")
        .annotate(so_don=Count("Ma_don_hang", distinct=True))
    )

    data = []
    for row in qs:
        tong = total_map.get(row["month"], 0)
        xac_suat = row["so_don"] / tong if tong else 0
        data.append({
            "Tháng": row["month"],
            "Mã nhóm hàng": row["Ma_nhom_hang"],
            "Tên nhóm hàng": row["Ten_nhom_hang"],
            "Số đơn": row["so_don"],
            "Tổng đơn tháng": tong,
            "Xác suất": xac_suat,
        })

    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})

def q9_data(request):
    # Tổng số đơn theo nhóm
    tong_nhom = (
        SaleRecord.objects
        .values("Ma_nhom_hang", "Ten_nhom_hang")
        .annotate(total=Count("Ma_don_hang", distinct=True))
    )
    tong_map = { (r["Ma_nhom_hang"], r["Ten_nhom_hang"]): r["total"] for r in tong_nhom }

    # Đếm số đơn theo mặt hàng trong nhóm
    qs = (
        SaleRecord.objects
        .values("Ma_nhom_hang", "Ten_nhom_hang", "Ma_mat_hang", "Ten_mat_hang")
        .annotate(count=Count("Ma_don_hang", distinct=True))
    )

    data = []
    for row in qs:
        group_key = (row["Ma_nhom_hang"], row["Ten_nhom_hang"])
        tong = tong_map.get(group_key, 0)
        xac_suat = row["count"] / tong if tong else 0
        data.append({
            "Nhóm hàng": f"[{row['Ma_nhom_hang']}] {row['Ten_nhom_hang']}",
            "Mặt hàng": f"[{row['Ma_mat_hang']}] {row['Ten_mat_hang']}",
            "Số đơn mặt hàng": row["count"],
            "Tổng đơn nhóm": tong,
            "Xác suất bán": xac_suat,
        })

    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})

def q10_data(request):
    # Tổng số đơn theo từng nhóm + tháng
    tong_theo_nhom_thang = (
        SaleRecord.objects
        .values("Ma_nhom_hang", "Ten_nhom_hang", "Thoi_gian_tao_don__month")
        .annotate(total=Count("Ma_don_hang", distinct=True))
    )
    tong_map = {
        (r["Ma_nhom_hang"], r["Ten_nhom_hang"], r["Thoi_gian_tao_don__month"]): r["total"]
        for r in tong_theo_nhom_thang
    }

    # Số đơn theo mặt hàng + nhóm + tháng
    qs = (
        SaleRecord.objects
        .values("Ma_nhom_hang", "Ten_nhom_hang",
                "Ma_mat_hang", "Ten_mat_hang",
                "Thoi_gian_tao_don__month")
        .annotate(count=Count("Ma_don_hang", distinct=True))
    )

    data = []
    for row in qs:
        total_group_orders = tong_map.get(
            (row["Ma_nhom_hang"], row["Ten_nhom_hang"], row["Thoi_gian_tao_don__month"]), 0
        )
        prob = row["count"] / total_group_orders if total_group_orders else 0
        data.append({
            "Nhóm hàng": f"[{row['Ma_nhom_hang']}] {row['Ten_nhom_hang']}",
            "Mặt hàng": f"[{row['Ma_mat_hang']}] {row['Ten_mat_hang']}",
            "Tháng": row["Thoi_gian_tao_don__month"],
            "Số đơn mặt hàng": row["count"],
            "Tổng đơn nhóm": total_group_orders,
            "Xác suất bán": prob,
        })

    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})

def q11_data(request):
    # B1: số lượt mua hàng (số đơn hàng) của mỗi khách hàng
    customer_orders = (
        SaleRecord.objects
        .values("Ma_KH")   # 🔥 dùng đúng field Ma_KH
        .annotate(order_count=Count("Ma_don_hang", distinct=True))
    )

    # B2: phân phối: bao nhiêu khách có N lượt mua
    distribution = {}
    for co in customer_orders:
        count = co["order_count"]
        distribution[count] = distribution.get(count, 0) + 1

    data = [
        {"Số lượt mua hàng": k, "Số lượng KH": v}
        for k, v in sorted(distribution.items())
    ]

    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})

def q12_data(request):
    spending_per_customer = (
        SaleRecord.objects
        .values("Ma_KH")   # ✅ phải đúng field
        .annotate(total_spending=Sum("Thanh_tien"))
    )

    bin_size = 50000
    distribution = {}

    for rec in spending_per_customer:
        spend = rec["total_spending"] or 0
        bin_floor = (spend // bin_size) * bin_size
        distribution[bin_floor] = distribution.get(bin_floor, 0) + 1

    data = [
        {
            "Khoảng chi tiêu": f"Từ {k:,} đến {(k+bin_size):,}",
            "Số lượng KH": v,
            "Chi tiêu KH": k
        }
        for k, v in sorted(distribution.items())
    ]
    return JsonResponse(data, safe=False, json_dumps_params={"ensure_ascii": False})
