(function () {
  d3.select("#Q10").selectAll("*").remove();
  d3.selectAll(".q10-tooltip").remove();

  const configs = {
    margin: { top: 40, right: 30, bottom: 50, left: 50 },
    chartWidth: 500,
    chartHeight: 300,
    cols: 3
  };

  const tooltip = d3.select("body").append("div")
    .attr("class", "q10-tooltip")
    .style("opacity", 0)
    .style("position", "absolute")
    .style("background", "rgba(255, 255, 255, 0.95)")
    .style("border", "1px solid #ccc")
    .style("padding", "8px")
    .style("border-radius", "4px")
    .style("pointer-events", "none")
    .style("font-size", "12px");

  d3.json("/q10-data/").then(itemMonth => {
    if (!itemMonth || itemMonth.length === 0) {
      d3.select("#Q10").append("div").style("color", "red").text("Không có dữ liệu từ API");
      return;
    }

    const months = d3.range(1, 13);
    const monthLabels = months.map(m => `T${String(m).padStart(2, "0")}`);

    // Gom nhóm theo nhóm hàng
    const groups = d3.groups(itemMonth, d => d["Nhóm hàng"]);

    const rowsCount = Math.ceil(groups.length / configs.cols);
    const totalWidth = configs.cols * configs.chartWidth;
    const totalHeight = rowsCount * configs.chartHeight + configs.margin.top;

    const svgAll = d3.select("#Q10").append("svg")
      .attr("width", totalWidth)
      .attr("height", totalHeight);

    const color = d3.scaleOrdinal(d3.schemeTableau10);

    groups.forEach(([groupName, dataG], gi) => {
      const itemsOfGroup = d3.groups(dataG, d => d["Mặt hàng"]);

      const dataCurves = itemsOfGroup.map(([itemKey, records]) => {
        const values = months.map(m => {
          const rec = records.find(d => d["Tháng"] === m);
          return { month: m, probability: rec ? rec["Xác suất bán"] : 0 };
        });
        return { itemKey, values };
      });

      const gx = (gi % configs.cols) * configs.chartWidth + configs.margin.left;
      const gy = Math.floor(gi / configs.cols) * configs.chartHeight + configs.margin.top;

      const gChart = svgAll.append("g")
        .attr("transform", `translate(${gx},${gy})`);

      gChart.append("text")
        .attr("x", (configs.chartWidth - configs.margin.left - configs.margin.right) / 2)
        .attr("y", -configs.margin.top / 2)
        .attr("text-anchor", "middle")
        .style("font-size", "14px")
        .style("font-weight", "600")
        .text(groupName);

      const xScale = d3.scalePoint()
        .domain(months)
        .range([0, configs.chartWidth - configs.margin.left - configs.margin.right])
        .padding(0.5);

      const yScale = d3.scaleLinear()
        .domain([0, d3.max(dataCurves, c => d3.max(c.values, v => v.probability)) || 1])
        .nice()
        .range([configs.chartHeight - configs.margin.top - configs.margin.bottom, 0]);

      const yAxis = d3.axisLeft(yScale).ticks(4).tickFormat(d3.format(".0%"));

      gChart.append("g")
        .attr("transform", `translate(0,${configs.chartHeight - configs.margin.top - configs.margin.bottom})`)
        .call(d3.axisBottom(xScale).tickValues(months).tickFormat(d => monthLabels[d - 1]))
        .call(g => g.select(".domain").remove())
        .style("font-size", "11px");

      gChart.append("g")
        .call(yAxis)
        .call(g => g.select(".domain").remove())
        .style("font-size", "11px");

      gChart.append("g")
        .call(d3.axisLeft(yScale)
          .tickSize(-(configs.chartWidth - configs.margin.left - configs.margin.right))
          .tickFormat(""))
        .lower()
        .selectAll("line")
        .style("stroke", "#ccc");

      dataCurves.forEach((curve, ii) => {
        const lineGen = d3.line()
          .x(d => xScale(d.month))
          .y(d => yScale(d.probability));

        gChart.append("path")
          .datum(curve.values)
          .attr("fill", "none")
          .attr("stroke", color(ii))
          .attr("stroke-width", 2)
          .attr("d", lineGen);

        gChart.selectAll(`.dot-${ii}`)
          .data(curve.values)
          .enter()
          .append("circle")
          .attr("class", "data-dot")
          .attr("cx", d => xScale(d.month))
          .attr("cy", d => yScale(d.probability))
          .attr("r", 3)
          .attr("fill", color(ii))
          .on("mouseover", function (event, d) {
            tooltip.transition().duration(100).style("opacity", 1);
            tooltip.html(`[${curve.itemKey}] ${(d.probability * 100).toFixed(1)}%`)
              .style("left", (event.pageX + 10) + "px")
              .style("top", (event.pageY - 28) + "px");
          })
          .on("mouseout", function () {
            tooltip.transition().duration(300).style("opacity", 0);
          });
      });
    });
  }).catch(err => {
    console.error("Q10.js error:", err);
    d3.select("#Q10").append("div").style("color", "red").text("Lỗi load /q10-data/");
  });
})();
