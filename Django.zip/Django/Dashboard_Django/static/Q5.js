const margin5 = { top: 80, right: 40, bottom: 60, left: 80 };
const width5 = 1400;
const height5 = 600;

const q5 = d3.select("#Q5")
  .append("svg")
  .attr("width", width5)
  .attr("height", height5);

// Tooltip
const tooltip5 = d3.select("body").append("div")
  .attr("class", "tooltip")
  .style("opacity", 0)
  .style("position", "absolute")
  .style("background", "#fff")
  .style("border", "1px solid #ccc")
  .style("padding", "8px")
  .style("border-radius", "4px")
  .style("pointer-events", "none")
  .style("font-size", "12px");

d3.json("/q5-data/").then(doanhSoTB => {
  // Ép kiểu và sort
  doanhSoTB.forEach(d => d["Doanh số TB"] = +d["Doanh số TB"]);
  doanhSoTB.sort((a, b) =>
    parseInt(a["Ngày trong tháng"].split(' ')[1]) -
    parseInt(b["Ngày trong tháng"].split(' ')[1])
  );

  const x = d3.scaleBand()
    .domain(doanhSoTB.map(d => d["Ngày trong tháng"]))
    .range([margin5.left, width5 - margin5.right])
    .padding(0.2);

  const y = d3.scaleLinear()
    .domain([0, 15e6]) // fix max 15 triệu
    .range([height5 - margin5.bottom, margin5.top]);

  // Grid ngang
  const grid = q5.append("g")
    .attr("class", "grid")
    .attr("transform", `translate(${margin5.left},0)`)
    .call(d3.axisLeft(y)
      .tickSize(-(width5 - margin5.left - margin5.right))
      .tickFormat("")
    );
  grid.lower();
  grid.selectAll("line")
    .style("stroke", "#ccc")
    .style("stroke-opacity", 0.4)
    .style("shape-rendering", "crispEdges");

  // Màu cho cột
  const mau = d3.scaleOrdinal()
    .range(["#02b8a8","#fc635d","#37474a","#f2c90f","#5f6c6e",
            "#8ad4eb","#ff9666","#b56bff","#ff80ab","#4caf50",
            "#ff9800","#9c27b0","#03a9f4","#795548","#607d8b"]);

  // Vẽ cột
  const cot = q5.selectAll(".bar")
    .data(doanhSoTB)
    .enter()
    .append("rect")
    .attr("class", "bar")
    .attr("x", d => x(d["Ngày trong tháng"]))
    .attr("y", d => y(d["Doanh số TB"]))
    .attr("width", x.bandwidth())
    .attr("height", d => y(0) - y(d["Doanh số TB"]))
    .attr("fill", (d, i) => mau(i))
    .on("mouseover", function (event, d) {
      tooltip5.transition().duration(200).style("opacity", 0.9);
      tooltip5.html(`
        <b>${d["Ngày trong tháng"]}</b><br>
        Doanh số TB: ${(d["Doanh số TB"]/1e6).toFixed(1)} tr
      `)
      .style("left", (event.pageX + 10) + "px")
      .style("top", (event.pageY - 28) + "px");
    })
    .on("mouseout", () => tooltip5.transition().duration(500).style("opacity", 0));

  // Nhãn trên cột
  q5.selectAll(".bar-label")
    .data(doanhSoTB)
    .enter()
    .append("text")
    .attr("class", "bar-label")
    .attr("x", d => x(d["Ngày trong tháng"]) + x.bandwidth()/2)
    .attr("y", d => y(d["Doanh số TB"]) - 5)
    .attr("text-anchor", "middle")
    .style("font-size", "12px")
    .style("font-weight", "bold")
    .style("fill", "white")
    .text(d => `${(d["Doanh số TB"]/1e6).toFixed(1)} tr`);

  // Trục X
  q5.append("g")
    .attr("transform", `translate(0,${height5 - margin5.bottom})`)
    .call(d3.axisBottom(x))
    .selectAll("text")
    .attr("transform", "rotate(0)")
    .style("text-anchor", "middle")
    .style("font-size", "11px");

  // Trục Y
  q5.append("g")
    .attr("transform", `translate(${margin5.left},0)`)
    .call(d3.axisLeft(y)
      .tickValues([0, 5e6, 10e6, 15e6])
      .tickFormat(d => `${(d/1e6).toFixed(0)}M`))
    .style("font-size", "11px");

  // Tiêu đề
  q5.append("text")
    .attr("x", width5/2)
    .attr("y", margin5.top/2)
    .attr("text-anchor", "middle")
    .style("font-size", "22px")
    .style("fill", "teal")
    .style("font-weight", "bold")
    .text("Doanh số bán hàng trung bình theo Ngày trong tháng");
});
