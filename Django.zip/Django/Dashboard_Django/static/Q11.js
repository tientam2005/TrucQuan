(function(){
  d3.select("#Q11").selectAll("*").remove();
  d3.selectAll(".q11-tooltip").remove();

  const margin = { top: 40, right: 40, bottom: 60, left: 80 };
  const width = 1400;
  const height = 600;

  // Tooltip
  const tooltip = d3.select("body").append("div")
    .attr("class", "q11-tooltip")
    .style("opacity", 0)
    .style("position", "absolute")
    .style("background", "#fff")
    .style("border", "1px solid #ccc")
    .style("padding", "10px")
    .style("pointer-events", "none")
    .style("text-align", "left");

  d3.json("/q11-data/").then(purchaseCountData => {
    if (!purchaseCountData || purchaseCountData.length === 0) {
      d3.select("#Q11").append("div").style("color","red").text("Không có dữ liệu từ API");
      return;
    }

    // Scale
    const x = d3.scaleBand()
      .domain(purchaseCountData.map(d => d["Số lượt mua hàng"].toString()))
      .range([0, width])
      .padding(0.2);

    const y = d3.scaleLinear()
      .domain([0, d3.max(purchaseCountData, d => d["Số lượng KH"])])
      .nice()
      .range([height, 0]);

    // SVG
    const svg = d3.select("#Q11")
      .append("svg")
      .attr("width", width + margin.left + margin.right)
      .attr("height", height + margin.top + margin.bottom)
      .append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    // Bars
    svg.selectAll(".bar")
      .data(purchaseCountData)
      .enter()
      .append("rect")
      .attr("class", "bar")
      .attr("x", d => x(d["Số lượt mua hàng"].toString()))
      .attr("y", d => y(d["Số lượng KH"]))
      .attr("width", x.bandwidth())
      .attr("height", d => height - y(d["Số lượng KH"]))
      .attr("fill", "#00bcd4")
      .on("mouseover", function (event, d) {
        tooltip.transition().duration(200).style("opacity", .9);
        tooltip.html(`
          <p>Số lượt mua hàng <strong>${d["Số lượt mua hàng"]}</strong></p>
          <p>Số lượng KH <strong>${d["Số lượng KH"].toLocaleString("vi-VN")}</strong></p>
        `)
          .style("left", (event.pageX + 5) + "px")
          .style("top", (event.pageY - 28) + "px")
          .style("font-size", "11px");
      })
      .on("mouseout", function () {
        tooltip.transition().duration(500).style("opacity", 0);
      });

    // Axis X
    svg.append("g")
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(x))
      .style("font-size", "11px")
      .call(g => g.select(".domain").remove());

    // Axis Y
    const yAxis = d3.axisLeft(y).ticks(5).tickFormat(d => d.toLocaleString("vi-VN"));
    svg.append("g")
      .call(yAxis)
      .style("font-size", "11px")
      .call(g => g.select(".domain").remove());

    // Grid ngang
    svg.append("g")
      .attr("class", "grid")
      .call(
        d3.axisLeft(y)
          .tickValues(y.ticks(5))
          .tickSize(-width)
          .tickFormat("")
      )
      .lower()
      .selectAll("line")
      .style("stroke", "#e0e0e0")
      .style("stroke-dasharray", "none");
  }).catch(err => {
    console.error("Q11.js error:", err);
    d3.select("#Q11").append("div").style("color","red").text("Lỗi load /q11-data/");
  });
})();
