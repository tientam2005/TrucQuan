const margin6 = { top: 40, right: 40, bottom: 60, left: 80 };
const width6 = 1400;
const height6 = 600;

const q6 = d3.select("#Q6")
  .append("svg")
  .attr("width", width6)
  .attr("height", height6);

const tooltip6 = d3.select("body").append("div")
  .attr("class", "tooltip")
  .style("opacity", 0)
  .style("position", "absolute")
  .style("background", "#fff")
  .style("border", "1px solid #ccc")
  .style("padding", "8px")
  .style("border-radius", "4px")
  .style("pointer-events", "none")
  .style("font-size", "12px");

d3.json("/q6-data/").then(data => {
  data.forEach(d => d["Doanh số TB"] = +d["Doanh số TB"]);

  const x = d3.scaleBand()
    .domain(data.map(d => d["Khung giờ"]))
    .range([margin6.left, width6 - margin6.right])
    .padding(0.2);

  const y = d3.scaleLinear()
    .domain([0, d3.max(data, d => d["Doanh số TB"]) || 0])
    .nice()
    .range([height6 - margin6.bottom, margin6.top]);

  const colors = d3.scaleOrdinal(d3.schemeTableau10);

  // Bars
  q6.selectAll(".bar")
    .data(data)
    .enter().append("rect")
    .attr("class", "bar")
    .attr("x", d => x(d["Khung giờ"]))
    .attr("y", d => y(d["Doanh số TB"]))
    .attr("width", x.bandwidth())
    .attr("height", d => y(0) - y(d["Doanh số TB"]))
    .attr("fill", (d, i) => colors(i))
    .on("mouseover", function (event, d) {
      tooltip6.transition().duration(200).style("opacity", 0.9);
      tooltip6.html(`
        <table>
          <tr><td>Khung giờ:</td><td><b>${d["Khung giờ"]}</b></td></tr>
          <tr><td>Doanh số TB:</td><td><b>${d["Doanh số TB"].toLocaleString("vi-VN")}</b></td></tr>
        </table>
      `)
      .style("left", (event.pageX + 10) + "px")
      .style("top", (event.pageY - 28) + "px");
    })
    .on("mouseout", () => tooltip6.transition().duration(500).style("opacity", 0));

  // Labels trên cột
  q6.selectAll(".bar-label")
    .data(data)
    .enter().append("text")
    .attr("class", "bar-label")
    .attr("x", d => x(d["Khung giờ"]) + x.bandwidth()/2)
    .attr("y", d => y(d["Doanh số TB"]) + 15)  
    .attr("text-anchor", "middle")
    .style("font-size", "10px")
    .style("fill", "white")
    .text(d => `${(d["Doanh số TB"]/1000).toFixed(1)}K`);

  // Trục X
  q6.append("g")
    .attr("transform", `translate(0,${height6 - margin6.bottom})`)
    .call(d3.axisBottom(x))
    .selectAll("text")
    //.attr("transform", "rotate(-45)")
    .style("text-anchor", "middle")
    .style("font-size", "11px");
  q6.selectAll(".domain").remove(); // xoá domain trục X

  // Trục Y
  q6.append("g")
    .attr("transform", `translate(${margin6.left},0)`)
    .call(d3.axisLeft(y).ticks(4).tickFormat(d => `${(d/1e6).toFixed(1)}M`))
    .style("font-size", "11px");
  q6.selectAll(".domain").remove(); // xoá domain trục Y

  // Grid ngang
  q6.append("g")
    .attr("class", "grid")
    .attr("transform", `translate(${margin6.left},0)`)
    .call(
      d3.axisLeft(y)
        .ticks(4)
        .tickSize(-(width6 - margin6.left - margin6.right))
        .tickFormat("")
    )
    .lower()
    .selectAll("line")
    .style("stroke", "#ccc")
    .style("stroke-opacity", 0.4)
    .style("shape-rendering", "crispEdges");
});
