from django.db import models

class SaleRecord(models.Model):
    Thoi_gian_tao_don = models.DateTimeField()             # Thời gian tạo đơn
    Ma_don_hang = models.CharField(max_length=20)      # Mã đơn hàng
    Ma_KH = models.CharField(max_length=20)   # Mã khách hàng
    Ten_KH = models.CharField(max_length=100)# Tên khách hàng
    Ma_PKKH = models.CharField(max_length=10)  # Mã PKKH
    Mo_ta_PKKH = models.TextField()               # Mô tả Phân Khúc KH
    Ma_nhom_hang = models.CharField(max_length=10)    # Mã nhóm hàng
    Ten_nhom_hang = models.CharField(max_length=50)    # Tên nhóm hàng
    Ma_mat_hang = models.CharField(max_length=20)     # Mã mặt hàng
    Ten_mat_hang = models.CharField(max_length=100)    # Tên mặt hàng
    Gia_nhap = models.IntegerField()              # Giá Nhập
    SL = models.IntegerField()                # SL
    Don_gia = models.IntegerField()              # Đơn giá
    Thanh_tien = models.IntegerField()             # Thành tiền

    def __str__(self):
        return f"{self.Ma_don_hang} - {self.Ten_mat_hang} - {self.Thanh_tien}"