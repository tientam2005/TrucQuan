// === Thiết lập kích thước và margin ===
const margin2 = { top: 40, right: 50, bottom: 80, left: 100 };
const width2 = 800;
const height2 = 500;

const q2 = d3.select("#Q2")
  .append("svg")
  .attr("width", width2)
  .attr("height", height2);

const colorScale2 = d3.scaleOrdinal(d3.schemeCategory10);

// Tooltip
const tooltip2 = d3.select("body")
  .append("div")
  .attr("class", "tooltip")
  .style("opacity", 0)
  .style("position", "absolute")
  .style("background", "white")
  .style("border", "1px solid #ccc")
  .style("padding", "6px 8px")
  .style("border-radius", "4px")
  .style("pointer-events", "none");

d3.json("/q2-data/").then(data => {
  // ép kiểu số
  data.forEach(d => {
    d["Thành tiền"] = +d["Thành tiền"];
    d["SL"] = +d["SL"];
    d["Nhóm hàng"] = `[${d["Mã nhóm hàng"]}] ${d["Tên nhóm hàng"]}`;
  });

  console.log("Q2 data:", data);

  // Sort theo doanh số
  data.sort((a, b) => d3.descending(a["Thành tiền"], b["Thành tiền"]));

  const x = d3.scaleBand()
    .domain(data.map(d => d["Nhóm hàng"]))
    .range([margin2.left, width2 - margin2.right])
    .padding(0.2);

  const y = d3.scaleLinear()
    .domain([0, d3.max(data, d => d["Thành tiền"])])
    .nice()
    .range([height2 - margin2.bottom, margin2.top]);

  // Bars
  const bars = q2.selectAll(".bar")
    .data(data)
    .enter()
    .append("rect")
    .attr("class", "bar")
    .attr("x", d => x(d["Nhóm hàng"]))
    .attr("y", d => y(d["Thành tiền"]))
    .attr("width", x.bandwidth())
    .attr("height", d => y(0) - y(d["Thành tiền"]))
    .attr("fill", d => colorScale2(d["Nhóm hàng"]))
    .on("mouseover", function(event, d) {
      tooltip2.transition().duration(200).style("opacity", 0.9);
      tooltip2.html(`
        <strong>${d["Nhóm hàng"]}</strong><br/>
        Doanh số: ${d["Thành tiền"].toLocaleString("vi-VN")} VND<br/>
        SL: ${d["SL"]}
      `)
      .style("left", (event.pageX + 10) + "px")
      .style("top", (event.pageY - 28) + "px");
    })
    .on("mouseout", function() {
      tooltip2.transition().duration(500).style("opacity", 0);
    });

  // Nhãn giá trị trên cột
  q2.selectAll(".bar-label")
    .data(data)
    .enter()
    .append("text")
    .attr("class", "bar-label")
    .attr("x", d => x(d["Nhóm hàng"]) + x.bandwidth() / 2)
    .attr("y", d => y(d["Thành tiền"]) - 5)
    .attr("text-anchor", "middle")
    .style("font-size", "11px")
    .text(d => `${Math.round(d["Thành tiền"] / 1e6)}M`);

  // Trục X
  q2.append("g")
    .attr("transform", `translate(0,${height2 - margin2.bottom})`)
    .call(d3.axisBottom(x))
    .selectAll("text")
    .attr("transform", "rotate(-30)")
    .style("text-anchor", "end")
    .style("font-size", "11px");

  // Trục Y
  q2.append("g")
    .attr("transform", `translate(${margin2.left},0)`)
    .call(d3.axisLeft(y).ticks(6).tickFormat(d => `${d/1e6}M`))
    .style("font-size", "11px");
});
