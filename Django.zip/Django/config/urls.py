"""
URL configuration for config project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from Dashboard_Django.views import (
    chart_view, q1_data, q2_data, q3_data, q4_data, q5_data, q6_data,
    q7_data, q8_data, q9_data, q10_data, q11_data, q12_data 
)
urlpatterns = [
    path('admin/', admin.site.urls),
    path('q1-data/', q1_data, name='q1_data'),
    path('q2-data/', q2_data, name='q2_data'),
    path('q3-data/', q3_data, name='q3_data'),
    path('q4-data/', q4_data, name='q4_data'),
    path('q5-data/', q5_data, name='q5_data'),
    path('q6-data/', q6_data, name='q6_data'),
    path('q7-data/', q7_data, name='q7_data'),
    path('q8-data/', q8_data, name='q8_data'),
    path('q9-data/', q9_data, name='q9_data'),
    path('q10-data/', q10_data, name='q10_data'),
    path('q11-data/', q11_data, name='q11_data'),
    path("q12-data/", q12_data, name="q12_data"),


    path('', chart_view, name='dashboard'),
]
