import csv
from datetime import datetime
from django.core.management.base import BaseCommand
from Dashboard_Django.models import SaleRecord

class Command(BaseCommand):
    help = "Import dữ liệu bán hàng từ file CSV vào SaleRecord"

    def add_arguments(self, parser):
        parser.add_argument('csv_path', type=str, help='Đường dẫn tới file CSV')

    def handle(self, *args, **options):
        csv_path = options['csv_path']
        count = 0

        with open(csv_path, newline='', encoding='utf-8-sig') as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    SaleRecord.objects.create(
                        Thoi_gian_tao_don=datetime.strptime(row['Thời gian tạo đơn'], "%Y-%m-%d %H:%M:%S"),
                        Ma_don_hang=row['Mã đơn hàng'],
                        Ma_KH=row['Mã khách hàng'],
                        Ten_KH=row['Tên khách hàng'],
                        Ma_PKKH=row['Mã PKKH'],
                        Mo_ta_PKKH=row['Mô tả Phân Khúc Khách hàng'],
                        Ma_nhom_hang=row['Mã nhóm hàng'],
                        Ten_nhom_hang=row['Tên nhóm hàng'],
                        Ma_mat_hang=row['Mã mặt hàng'],
                        Ten_mat_hang=row['Tên mặt hàng'],
                        Gia_nhap=int(row['Giá Nhập']),
                        SL=int(row['SL']),
                        Don_gia=int(row['Đơn giá']),
                        Thanh_tien=int(row['Thành tiền'])
                    )
                    count += 1
                except Exception as e:
                    self.stderr.write(self.style.WARNING(f"Lỗi ở dòng {row}: {e}"))

        self.stdout.write(self.style.SUCCESS(f"✅ Đã import {count} dòng từ {csv_path}"))
