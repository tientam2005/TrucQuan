const margin4 = { top: 40, right: 40, bottom: 60, left: 80 };
const width4 = 1400;
const height4 = 600;

const q4 = d3.select("#Q4")
  .append("svg")
  .attr("width", width4)
  .attr("height", height4);

// Thứ trong tuần theo thứ tự
const weekday_order = ["Thứ Hai", "Thứ Ba", "Thứ Tư", "Thứ Năm", "Thứ Sáu", "Thứ Bảy", "Chủ Nhật"];

// Màu
const colors4 = ["#02b8a8", "#37474a", "#fc635d", "#f2c90f", "#5f6c6e", "#8ad4eb","#ff9666"];
const colorScale4 = d3.scaleOrdinal().range(colors4);

// Tooltip
const tooltip4 = d3.select("body").append("div")
  .attr("class", "tooltip")
  .style("opacity", 0)
  .style("position", "absolute")
  .style("background", "white")
  .style("border", "1px solid #ccc")
  .style("padding", "6px 8px")
  .style("border-radius", "4px")
  .style("pointer-events", "none")
  .style("font-size", "12px");

// === Đọc dữ liệu ===
d3.json("/q4-data/").then(raw => {
  // Sắp theo thứ tự chuẩn (đề phòng API trả thiếu thứ nào đó)
  const map = Object.fromEntries(raw.map(d => [d["Ngày trong tuần"], +d["Thành tiền"] || 0]));
  const data = weekday_order.map(name => ({
    "Ngày trong tuần": name,
    "Thành tiền": map[name] || 0
  }));

  // Bars
  const bars = q4.selectAll(".bar")
    .data(data)
    .enter()
    .append("rect")
    .attr("class", "bar")
    .attr("x", d => x(d["Ngày trong tuần"]))
    .attr("y", d => y(d["Thành tiền"]))
    .attr("width", x.bandwidth())
    .attr("height", d => y(0) - y(d["Thành tiền"]))
    .attr("fill", d => colorScale4(d["Ngày trong tuần"]))
    .on("mouseover", function (event, d) {
      tooltip4.transition().duration(200).style("opacity", 0.9);
      tooltip4.html(`
        <table style="border-collapse:collapse;">
          <tr>
            <td style="padding-right:8px;text-align:right;">Ngày trong tuần</td>
            <td style="text-align:left;"><strong>${d["Ngày trong tuần"]}</strong></td>
          </tr>
          <tr>
            <td style="padding-right:8px;text-align:right;">Doanh số bán TB</td>
            <td style="text-align:left;"><strong>${(d["Thành tiền"]).toLocaleString("vi-VN")}</strong></td>
          </tr>
        </table>
      `)
      .style("left", (event.pageX + 10) + "px")
      .style("top", (event.pageY - 28) + "px");
    })

    .on("mouseout", function () {
      tooltip4.transition().duration(500).style("opacity", 0);
    })

    .on("click", function (event, d) {
      if (d3.select(this).attr("opacity") !== "1") {
        bars.attr("opacity", 0.3);
        d3.select(this).attr("opacity", 1);
      } else {
        bars.attr("opacity", 1);
      }
    });

  // Nhãn trên cột
  q4.selectAll(".bar-label")
    .data(data)
    .enter()
    .append("text")
    .attr("class", "bar-label")
    .attr("x", d => x(d["Ngày trong tuần"]) + x.bandwidth() / 2)
    .attr("y", d => y(d["Thành tiền"]) +12)
    .attr("text-anchor", "middle")
    .style("font-size", "11px")
    .text(d => `${Math.round(d["Thành tiền"]).toLocaleString("vi-VN")} VND`);

  // Trục X
  q4.append("g")
    .attr("transform", `translate(0,${height4 - margin4.bottom})`)
    .call(d3.axisBottom(x))
    .call(g => g.select(".domain").remove());

  // Trục Y
  const yTicks = d3.range(0, 15000001, 5000000)    
  q4.append("g")
    .attr("transform", `translate(${margin3.left},0)`)
    .call(d3.axisLeft(y)
      .tickValues(yTicks)
      .tickFormat(d => `${(d / 1e6).toFixed(0)}M`) 
    )
    .call(g => g.select(".domain").remove())
    .style("font-size", "11px");

// Grid ngang
q4.append("g")
    .attr("class", "grid")
    .attr("transform", `translate(${margin3.left},0)`)
    .call(
      d3.axisLeft(y)
        .tickSize(-(width3 - margin3.left - margin3.right)) 
        .tickFormat("") 
        .ticks(4)
    )
    .lower() 
    .selectAll("line")
    .style("stroke", "#ccc")
    .style("stroke-opacity", 0.4)
    .style("shape-rendering", "crispEdges");
 });
