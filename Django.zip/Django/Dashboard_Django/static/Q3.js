const margin3 = { top: 40, right: 40, bottom: 60, left: 80 };
const width3 = 1400;
const height3 = 600;

const q3 = d3.select("#Q3")
  .append("svg")
  .attr("width", width3)
  .attr("height", height3);

const colors3 = ["#02b8a8", "#37474a", "#fc635d", "#f2c90f", "#5f6c6e", "#8ad4eb",
                "#ff9666", "#a66898", "#3599b8", "#debfbf", "#4bc4ba", "#5f6c6e"];
const colorScale3 = d3.scaleOrdinal().range(colors3);

const tooltip3 = d3.select("body").append("div")
  .attr("class", "tooltip")
  .style("opacity", 0)
  .style("position", "absolute")
  .style("background", "white")
  .style("border", "1px solid #ccc")
  .style("padding", "6px 8px")
  .style("border-radius", "4px")
  .style("pointer-events", "none")
  .style("font-size", "12px");

d3.json("/q3-data/").then(data => {
  console.log("Q3 raw:", data);
  
  if (!data || data.length === 0) {
    d3.select("#Q3").append("p").text("⚠️ Không có dữ liệu để hiển thị");
    return;
  }

  data.forEach(d => {
    d["Thành tiền"] = +d["Thành tiền"] || 0;
    d["SL"] = +d["SL"] || 0;
  });

  console.log("Q3 parsed:", data);

  const x = d3.scaleBand()
    .domain(data.map(d => d["Tháng"]))
    .range([margin3.left, width3 - margin3.right])
    .padding(0.2);

  const y = d3.scaleLinear()
    .domain([0, d3.max(data, d => d["Thành tiền"])]).nice()
    .range([height3 - margin3.bottom, margin3.top]);

  const bars = q3.selectAll(".bar")
    .data(data)
    .enter()
    .append("rect")
    .attr("class", "bar")
    .attr("x", d => x(d["Tháng"]))
    .attr("y", d => y(d["Thành tiền"]))
    .attr("width", x.bandwidth())
    .attr("height", d => y(0) - y(d["Thành tiền"]))
    .attr("fill", (d, i) => colorScale3(i))
    .on("mouseover", function (event, d) {
      tooltip3.style("opacity", 1)
        .html(`
          <table style="border-collapse:collapse;">
            <tr>
              <td style="padding-right:8px;text-align:right;">Tháng</td>
              <td style="text-align:left;"><strong>${d["Tháng"]}</strong></td>
            </tr>
            <tr>
              <td style="padding-right:8px;text-align:right;">Doanh số bán</td>
              <td style="text-align:left;"><strong>${d["Thành tiền"].toLocaleString("vi-VN")} VND</strong></td>
            </tr>
          </table>
        `);
    })
    .on("mousemove", function (event) {
      tooltip3
        .style("left", (event.pageX + 12) + "px")
        .style("top", (event.pageY - 28) + "px");
    })
    .on("mouseout", function () {
      tooltip3.transition().duration(500).style("opacity", 0);
    })
    .on("click", function (event, d) {
      if (d3.select(this).attr("opacity") !== "1") {
        bars.attr("opacity", 0.3);
        d3.select(this).attr("opacity", 1);
      } else {
        bars.attr("opacity", 1);
      }
    });
  // Nhãn trên cột
  q3.selectAll(".bar-label")
    .data(data)
    .enter()
    .append("text")
    .attr("class", "bar-label")
    .attr("x", d => x(d["Tháng"]) + x.bandwidth() / 2)
    .attr("y", d => y(d["Thành tiền"]) +15)
    .attr("text-anchor", "middle")
    .style("font-size", "12px")
    .style("fill", "#ffffffff")
    .text(d => `${Math.round(d["Thành tiền"]/1e6)} triệu VND`);


// Trục X
q3.append("g")
  .attr("transform", `translate(0,${height3 - margin3.bottom})`)
  .call(d3.axisBottom(x))
  .call(g => g.select(".domain").remove())
  .call(g => g.selectAll("line").remove());

// Trục Y + Grid
const yTicks = d3.range(0, 800000001, 200000000);

q3.append("g")
  .attr("transform", `translate(${margin3.left},0)`)
  .call(
    d3.axisLeft(y)
      .tickValues(yTicks)
      .tickFormat(d => `${d / 1e6}M`)
  )
  .call(g => g.select(".domain").remove())
  .call(g => g.selectAll("line").remove());

// Grid ngang (vẽ trước hoặc dùng .lower() để nằm dưới cột)
const plotWidth3 = x.range()[1] - x.range()[0];

q3.append("g")
  .attr("class", "grid")
  .attr("transform", `translate(${margin3.left},0)`)
  .call(
    d3.axisLeft(y)
      .tickValues(yTicks)
      .tickSize(-plotWidth3)
      .tickFormat("")
  )
  .lower()  // đẩy grid xuống dưới bar
  .selectAll("line")
  .style("stroke", "#ccc")
  .style("stroke-opacity", 0.4)
  .style("shape-rendering", "crispEdges");

});
