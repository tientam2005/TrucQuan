// === Thiết lập kích thước và margin ===
const margin1 = { top: 40, right: 250, bottom: 50, left: 260 };
const width1 = 1200;
const height1 = 600;

const q1 = d3.select("#Q1")
  .append("svg")
  .attr("width", width1)
  .attr("height", height1);

const colorScale1 = d3.scaleOrdinal()
  .domain(["BOT", "SET", "THO", "TMX", "TTC"])
  .range(["#02b8a8", "#37474a", "#fc635d","#f2c90f","#5f6c6e" ]);

// tooltip trước khi vẽ
const tooltip = d3.select("body")
  .append("div")
  .attr("class", "tooltip")
  .style("opacity", 0)
  .style("position", "absolute")
  .style("background", "white")
  .style("border", "1px solid #ccc")
  .style("padding", "6px 8px")
  .style("border-radius", "4px")
  .style("pointer-events", "none");


d3.json("/q1-data/").then(data => {
  // ép kiểu số và tạo label hiển thị
  data.forEach(d => {
    d["Thành tiền"] = +d["Thành tiền"];
    d["SL"] = +d["SL"];
    d["Mặt hàng"] = `[${d["Mã mặt hàng"]}] ${d["Tên mặt hàng"]}`;
    d["Nhóm hàng"] = `[${d["Mã nhóm hàng"]}] ${d["Tên nhóm hàng"]}`;
  });

  console.log("Q1 data:", data); // kiểm tra log

  const sales = d3.rollups(
    data,
    v => ({
      "Thành tiền": d3.sum(v, d => d["Thành tiền"]),
      "SL": d3.sum(v, d => d["SL"]),
      "Nhóm hàng": v[0]["Nhóm hàng"]
    }),
    d => d["Mặt hàng"]
  ).map(([key, value]) => ({ "Mặt hàng": key, ...value }));

  sales.sort((a, b) => d3.descending(a["Thành tiền"], b["Thành tiền"]));

  const x = d3.scaleLinear()
    .domain([0, d3.max(sales, d => d["Thành tiền"])])
    .range([margin1.left, width1 - margin1.right]);

  const y = d3.scaleBand()
    .domain(sales.map(d => d["Mặt hàng"]))
    .range([margin1.top, height1 - margin1.bottom])
    .padding(0.2);

  const bars = q1.selectAll(".bar")
    .data(sales)
    .enter()
    .append("rect")
    .attr("class", "bar")
    .attr("y", d => y(d["Mặt hàng"]))
    .attr("x", margin1.left)
    .attr("width", d => x(d["Thành tiền"]) - margin1.left)
    .attr("height", y.bandwidth())
    .attr("fill", d => colorScale1(d["Nhóm hàng"]))
    .on("mouseover", function (event, d) {
      tooltip.transition().duration(200).style("opacity", 0.9);
      tooltip.html(`
        <table style="border-collapse:collapse;">
          <tr>
            <td style="padding-right:8px;text-align:right;">Mặt hàng</td>
            <td style="text-align:left;"><strong>${d["Mặt hàng"]}</strong></td>
          </tr>
          <tr>
            <td style="padding-right:8px;text-align:right;">Nhóm hàng</td>
            <td style="text-align:left;"><strong>${d["Nhóm hàng"]}</strong></td>
          </tr>
          <tr>
            <td style="padding-right:8px;text-align:right;">Doanh số bán</td>
            <td style="text-align:left;"><strong>${(d["Thành tiền"]).toLocaleString("vi-VN")}</strong></td>
          </tr>
        </table>
      `)
      .style("left", (event.pageX + 10) + "px")
      .style("top", (event.pageY - 28) + "px");
    })

    .on("mouseout", function () {
      tooltip.transition().duration(500).style("opacity", 0);
    })
    .on("click", function (event, d) {
      if (d3.select(this).attr("opacity") !== "1") {
        bars.attr("opacity", 0.3);
        d3.select(this).attr("opacity", 1);
      } else {
        bars.attr("opacity", 1);
      }
    });

  // Nhãn cột (canh phải hoặc trái tùy chiều rộng cột)
  q1.selectAll(".bar-label")
    .data(sales)
    .enter()
    .append("text")
    .attr("class", "bar-label")
    .attr("x", d => {
      const barWidth = x(d["Thành tiền"]) - margin1.left;
      return barWidth > 60 ? x(d["Thành tiền"]) - 8 : margin1.left + 5;
    })
    .attr("y", d => y(d["Mặt hàng"]) + y.bandwidth() / 2)
    .attr("dy", "0.35em")
    .attr("text-anchor", d => {
      const barWidth = x(d["Thành tiền"]) - margin1.left;
      return barWidth > 60 ? "end" : "start";
    })
    .style("font-size","10px")
    .text(d => `${Math.round(d["Thành tiền"]/1e6)} triệu VND`);

  // Trục X grid
  const xTicks = d3.range(0, 700000001, 50000000);
  q1.append("g")
    .attr("class", "grid")
    .attr("transform", `translate(0,${height1 - margin1.bottom})`)
    .call(
      d3.axisBottom(x)
      .tickValues(xTicks)
        .tickSize(-(height1 - margin1.top - margin1.bottom))
        .tickFormat("")
    )
    .lower()
    .selectAll("line")
    .style("stroke", "#ccc")
    .style("stroke-opacity", 0.4)
    .style("shape-rendering", "crispEdges");

  // Trục X chính
  const xAxis = d3.axisBottom(x)
    .tickValues(xTicks)
    .tickFormat(d => `${(d / 1000000).toFixed(0)}M`);

  q1.append("g")
    .attr("transform", `translate(0,${height1 - margin1.bottom})`)
    .call(xAxis)
    .call(g => g.select(".domain").remove())
    .selectAll("text")
    .style("font-size","11px");

  // Trục Y
  q1.append("g")
    .attr("transform", `translate(${margin1.left},0)`)
    .call(d3.axisLeft(y))
    .call(g => g.select(".domain").remove())
    .selectAll("text")
    .style("font-size","11px");

  // Lấy giá trị x max thực tế (tức toạ độ pixel cuối cùng của cột x)
  const xMax = x(d3.max(sales, d => d["Thành tiền"])); 
  // tạo legend tại vị trí ngay bên phải xMax + 20px
  const legend = q1.append("g")
  .attr("class","legend")
  .attr("transform",`translate(${xMax + 100},${margin1.top})`);

  //tiêu đề lengend
  legend.append("text")
    .attr("x",0)
    .attr("y",0)
    .style("font-size","13px")
    .style("font-weight","bold")
    .text("Nhóm hàng");

  // Legend nhóm hàng
  const uniqueGroups = Array.from(new Set(data.map(d => d["Nhóm hàng"])))
    .sort((a,b)=>d3.ascending(a,b));

  const legendItem = legend.selectAll(".legend-item")
    .data(uniqueGroups)
    .enter().append("g")
    .attr("class","legend-item")
    .attr("transform",(d,i)=>`translate(0,${(i*20) + 20})`);

  legendItem.append("circle")
    .attr("cx",0).attr("cy",0).attr("r",5)
    .attr("fill",d=>colorScale1(d));

  legendItem.append("text")
    .attr("x",10).attr("y",3)
    .style("font-size","11px")
    .style("font-weight","normal")
    .text(d=>d);
});