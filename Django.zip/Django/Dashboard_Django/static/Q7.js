const margin7 = { top: 40, right: 40, bottom: 60, left: 160 };
const width7 = 1200;
const height7 = 500;

const q7 = d3.select("#Q7")
  .append("svg")
  .attr("width", width7)
  .attr("height", height7);

// Tooltip
const tooltip7 = d3.select("body").append("div")
  .attr("class", "tooltip")
  .style("opacity", 0)
  .style("position", "absolute")
  .style("background", "#fff")
  .style("border", "1px solid #ccc")
  .style("padding", "8px")
  .style("border-radius", "4px")
  .style("pointer-events", "none")
  .style("font-size", "12px");

d3.json("/q7-data/").then(groups => {
  groups.sort((a, b) => d3.descending(a["Xác suất"], b["Xác suất"]));

  // Scale
  const y = d3.scaleBand()
    .domain(groups.map(d => d["Nhóm hàng"]))
    .range([margin7.top, height7 - margin7.bottom])
    .padding(0.2);

  const x = d3.scaleLinear()
    .domain([0, d3.max(groups, d => d["Xác suất"])])
    .range([margin7.left, width7 - margin7.right]);

  // Màu
  const mau7 = d3.scaleOrdinal()
    .range(["#f2c90f", "#fc635d", "#5f6c6e", "#02b8a8", "#37474a"]);

  // Bars
  q7.selectAll(".bar")
    .data(groups)
    .enter()
    .append("rect")
    .attr("class", "bar")
    .attr("y", d => y(d["Nhóm hàng"]))
    .attr("x", margin7.left)
    .attr("height", y.bandwidth())
    .attr("width", d => x(d["Xác suất"]) - margin7.left)
    .attr("fill", (d, i) => mau7(i))
    .on("mouseover", (event, d) => {
      tooltip7.transition().duration(200).style("opacity", 0.9);
      tooltip7.html(`
        <p>Nhóm hàng <strong>${d["Nhóm hàng"]}</strong> </p>
        Xác suất Bán <strong>${(d["Xác suất"] * 100).toFixed(0)}% </strong> </p> `)
      .style("left", (event.pageX + 10) + "px")
      .style("top", (event.pageY - 28) + "px");
    })
    .on("mouseout", () => tooltip7.transition().duration(400).style("opacity", 0));

  // Label bên trong cột
  q7.selectAll(".bar-label")
    .data(groups)
    .enter()
    .append("text")
    .attr("x", d => x(d["Xác suất"]) - 35)   // đặt sát bên phải trong cột
    .attr("y", d => y(d["Nhóm hàng"]) + y.bandwidth() / 2)
    .attr("text-anchor", "end")
    .attr("dominant-baseline", "end")
    .style("font-size", "12px")
    .style("fill", "white")
    .style("font-weight", "bold")
    .text(d => `${(d["Xác suất"] * 100).toFixed(1)}%`);

  // Axis X
  q7.append("g")
    .attr("transform", `translate(0,${height7 - margin7.bottom})`)
    .call(d3.axisBottom(x).ticks(5).tickFormat(d3.format(".0%")))
    .style("font-size", "12px")
    .call(g => g.select(".domain").remove())
    .call(g => g.selectAll("line").remove());

  // Axis Y
  q7.append("g")
    .attr("transform", `translate(${margin7.left},0)`)
    .call(d3.axisLeft(y))
    .style("font-size", "12px")
    .call(g => g.select(".domain").remove())
    .call(g => g.selectAll("line").remove());

  // Grid dọc
  const grid = q7.append("g")
    .attr("class", "grid")
    .attr("transform", `translate(0,${height7 - margin7.bottom})`)
    .call(d3.axisBottom(x)
      .ticks(6)
      .tickSize(-(height7 - margin7.top - margin7.bottom))
      .tickFormat("")
    );
  grid.lower();
  grid.selectAll("line")
    .style("stroke", "#ccc")
    .style("stroke-opacity", 0.4)
    .style("shape-rendering", "crispEdges");
});
